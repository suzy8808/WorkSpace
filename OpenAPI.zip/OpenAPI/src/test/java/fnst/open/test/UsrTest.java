package fnst.open.test;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import redis.clients.jedis.Jedis;
import fnst.open.db.JedisClient;
import fnst.open.entity.Usr;
import fnst.open.service.IUsrService;

@RunWith(SpringJUnit4ClassRunner.class)//4.1.2以上版本
@ContextConfiguration("classpath*:applicationContext.xml")
public class UsrTest {
	@Autowired
	private IUsrService usrService;
	@Autowired
	private JedisClient jedisClient;
	
	
	/*@Test
	public void testLogin(){
		System.out.println(usrService.login("李晓峰2", "123"));
	}*/
	/*@Test
	public void testAddUsr(){
		Usr usr=new Usr();
		usr.setName("李晓峰2");
		usr.setPassword("123");
		System.out.println(usrService.addUsr(usr));
	}*/
	
	@Test
	public void testJedis(){
		
		Jedis jedisW=jedisClient.getWriteResource();
		jedisW.set("name", "张无忌2");
		jedisClient.returnResource(jedisW);
		Jedis jedisR=jedisClient.getReadResource();
		System.out.println(jedisR.get("name"));
		jedisClient.returnResource(jedisR);
		
	}
}
