package fnst.open.service;

import fnst.open.entity.Usr;

public interface IUsrService {
	
	public Usr login(String name,String password);
	public int addUsr(Usr usr); 
}
