package fnst.open.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fnst.open.dao.UsrMapper;
import fnst.open.db.DataSource;
import fnst.open.entity.Usr;
import fnst.open.service.IUsrService;

@Service
public class UsrService implements IUsrService {

	@Autowired
	private UsrMapper usrMapper;
	
	@DataSource("read")
	@Override
	public Usr login(String name, String password) {
		Map<String,Object> map=new HashMap<String, Object>();
		map.put("name", name);
		map.put("password", password);
		Usr usr=usrMapper.selectByNameAndPassword(map);
		return usr;
	}
	
	@DataSource("write")
	@Override
	public int addUsr(Usr usr) {
		
		return usrMapper.insertSelective(usr);
	}
	
	

}
