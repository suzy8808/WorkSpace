package fnst.open.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import fnst.open.entity.Usr;
import fnst.open.service.IUsrService;
@RequestMapping("/usr")
@Controller
public class UsrController {
	@Autowired
	private IUsrService usrService;
	
	@RequestMapping("/login")
	@ResponseBody
	public Object login(HttpServletRequest request,HttpServletResponse response) throws IOException{
		String name=null;
		String password=null;
		//JSONObject jo=new JSONObject();
		StringBuilder param=new StringBuilder();
		InputStream in=null;
		BufferedReader br=null;
		try {
			in = request.getInputStream();
			br=new BufferedReader(new InputStreamReader(in));
			String line;
			while((line=br.readLine())!=null){
				param.append(line);
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		in.close();
		br.close();
		JSONObject jo=JSONObject.parseObject(param.toString());
		
		
		name=jo.getString("name");
		password=jo.getString("password");
		Logger logger=Logger.getLogger(UsrController.class.getName());
		logger.info(jo.toString());
		Usr usr=usrService.login(name, password);
		if(usr==null){
			/*PrintWriter out=response.getWriter();
			out.write("login fail\t"+"name="+name+"\tpassword="+password);
			out.flush();*/
			return "failed";
		}else{
			/*PrintWriter out=response.getWriter();
			out.write("login success\t"+usr);
			out.flush();*/
			return usr;
		}
			
		
	}
}
