package fnst.open.dao;

import java.util.Map;

import fnst.open.entity.Usr;

public interface UsrMapper {
    int deleteByPrimaryKey(Long id);

    int insert(Usr record);

    int insertSelective(Usr record);

    Usr selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(Usr record);

    int updateByPrimaryKey(Usr record);
    
    Usr selectByNameAndPassword(Map map);
}