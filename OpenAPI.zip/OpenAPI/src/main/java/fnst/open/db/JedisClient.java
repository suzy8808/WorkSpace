package fnst.open.db;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class JedisClient {
		//jedis写连接池
		private JedisPool jedisWPool;
		//jedis读连接池
		private JedisPool jedisRPool;

		

		public JedisClient(JedisPool jedisWPool, JedisPool jedisRPool) {
			super();
			this.jedisWPool = jedisWPool;
			this.jedisRPool = jedisRPool;
		}

		public Jedis getWriteResource(){
			return jedisWPool.getResource();
		}
		
		public Jedis getReadResource(){
			return jedisRPool.getResource();
		}

		/**
		 * Description: 将jedis连接放回连接池中
		 * @param resource void
		 */
		public void returnResource(Jedis resource) {
			//jedisPool.returnResource(resource);
			if(resource!=null){
				resource.close();
			}
		}
		
		
		
		

}
