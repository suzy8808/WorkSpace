CREATE TABLE public.usr
(
    id serial,
    name text,
    password text,
    PRIMARY KEY (id),
    UNIQUE (name)
)
WITH (
    OIDS = FALSE
);

ALTER TABLE public.usr
    OWNER to postgres;
    

