package fnst.web.dao;

import fnst.web.entity.Word;

public interface WordMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Word record);

    int insertSelective(Word record);

    Word selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Word record);

    int updateByPrimaryKey(Word record);
}