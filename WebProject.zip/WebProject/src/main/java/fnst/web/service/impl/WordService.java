package fnst.web.service.impl;

import java.security.NoSuchAlgorithmException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fnst.web.dao.UsrMapper;
import fnst.web.dao.WordMapper;
import fnst.web.entity.Usr;
import fnst.web.entity.Word;
import fnst.web.service.IUsrService;
import fnst.web.service.IWordService;
import fnst.web.utils.MD5Utils;

@Service
public class WordService implements IWordService {

	@Autowired
	private UsrMapper usrMapper;
	@Autowired
	private WordMapper wordMapper;
	
	@Override
	public void writeWord(Usr usr, String content) throws NoSuchAlgorithmException {
		Usr user=usrMapper.selectByPrimaryKey(usr.getId());
		if(user!=null){
			Word word=new Word();
			word.setContent(content);
			word.setUsrId(user.getId());
			wordMapper.insert(word);
			
		}else{
			throw new IllegalArgumentException();
		}

	}

}
