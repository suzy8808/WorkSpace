package fnst.web.service;

import java.security.NoSuchAlgorithmException;

import fnst.web.entity.Usr;

public interface IWordService {
	public void writeWord(Usr usr,String content) throws NoSuchAlgorithmException;
}
