package fnst.web.service.impl;

import java.util.HashMap;
import fnst.web.db.DataSource;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fnst.web.dao.UsrMapper;
import fnst.web.entity.Usr;
import fnst.web.service.IUsrService;
@Service
public class UsrService implements IUsrService {

	@Autowired
	private UsrMapper usrMapper;
	@Override
	public Usr login(String name, String password) {
		Map<String,Object> map=new HashMap();
		map.put("name",name);
		map.put("password",password);
		return usrMapper.selectByNameAndPassword(map);
	}
	@DataSource("write")
	@Override
	public int insert(Usr record) {
		// TODO Auto-generated method stub
		return usrMapper.insert(record);
	}
	
	@DataSource("write")
	@Override
	public Usr selectByPrimaryKey(Long id) {
		// TODO Auto-generated method stub
		return usrMapper.selectByPrimaryKey(id);
	}
	@DataSource("write")
	@Override
	public int insertSelective(Usr record) {
		// TODO Auto-generated method stub
		return usrMapper.insertSelective(record);
	}

}
