package fnst.web.service;

import org.springframework.stereotype.Service;

import fnst.web.entity.Usr;


public interface IUsrService {
	public Usr login(String name,String password);
	
	int insert(Usr record);
	Usr selectByPrimaryKey(Long id);
	int insertSelective(Usr record);
}
