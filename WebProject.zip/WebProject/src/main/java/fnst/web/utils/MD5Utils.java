package fnst.web.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;


public class MD5Utils {
	public static String EncoderByMd5(String str) throws NoSuchAlgorithmException{
		MessageDigest md5=MessageDigest.getInstance("MD5");
		byte[] bytes=md5.digest(str.getBytes());
		StringBuffer sb=new StringBuffer();
		for(byte b:bytes){
			int num=b&0xff;
			String s=Integer.toHexString(num);
			if(s.length()<2){
				sb.append('0');
			}
			sb.append(s);
			
		}
		return sb.toString();
		
	}
	
	
}
