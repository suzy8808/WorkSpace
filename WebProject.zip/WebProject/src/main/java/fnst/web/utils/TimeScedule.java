package fnst.web.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class TimeScedule {
	private SynDataBase synDataBase;
	public TimeScedule() {
		List<String> TBNames=new ArrayList<String>();
		TBNames.add("usr");
		synDataBase=new SynDataBase(TBNames,3);
		Runnable runnable=new Runnable() {
			
			@Override
			public void run() {
				try {
					synDataBase.synDataBase();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
			}
		};
		
		ScheduledExecutorService service=Executors.newSingleThreadScheduledExecutor();
		service.scheduleAtFixedRate(runnable, 10, 10, TimeUnit.SECONDS);
	}
}
