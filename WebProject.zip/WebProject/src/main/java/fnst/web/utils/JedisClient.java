package fnst.web.utils;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

public class JedisClient {
		//jedis连接池
		private JedisPool jedisPool;

		public void setJedisPool(JedisPool jedisPool) {
			this.jedisPool = jedisPool;
		}

		/**   
		 * Description: 从连接池中获取jedis连接
		 * @return Jedis
		 */
		public Jedis getResource() {
			return jedisPool.getResource();
		}

		/**
		 * Description: 将jedis连接放回连接池中
		 * @param resource void
		 */
		public void returnResource(Jedis resource) {
			//jedisPool.returnResource(resource);
			if(resource!=null){
				resource.close();
			}
		}
		
		
		
		

}
