package fnst.web.utils;

public enum DataBase {
	WriteDataBase("org.postgresql.Driver",
			"jdbc:postgresql://localhost:5432/xyb_db",
			"postgres",
			"fnst1234"),
	ReadDataBase("org.postgresql.Driver",
			"jdbc:postgresql://localhost:5432/xyb_db2",
			"postgres",
			"fnst1234");
	public String driverClassName;
	public String url;
	public String username;
	public String password;
	private DataBase(String driverClassName, String url, String username,
			String password) {
		this.driverClassName = driverClassName;
		this.url = url;
		this.username = username;
		this.password = password;
	}
	
}
