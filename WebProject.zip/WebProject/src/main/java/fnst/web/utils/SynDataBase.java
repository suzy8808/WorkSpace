package fnst.web.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class SynDataBase {
	private List<String> coreTBNames;//需要同步的核心库表名
	private AtomicLong currentSynCount=new AtomicLong(0L);//当前已同步的条数
	private int syncThreadNum;//同步的线程数
	
	
	public void synDataBase() throws Exception{
		System.out.println("同步数据库");
		synData();
		
	}
	
	public SynDataBase(List<String> coreTBNames, int syncThreadNum) {
		super();
		this.coreTBNames = coreTBNames;
		this.syncThreadNum = syncThreadNum;
	}

	private void synData() throws Exception{
		for(String tmpTBName:coreTBNames){
			System.out.println("Table Name:"+tmpTBName);
			PostgresqlJDBC postgresWR=PostgresqlJDBC.createPostgresqlJava(DataBase.WriteDataBase);
			ResultSet coreRs=postgresWR.selectCount(tmpTBName);
			coreRs.next();
			long totalNum=coreRs.getLong(1);
			long ownerRecordNum=(long)Math.ceil((totalNum/syncThreadNum));
			System.out.println("需要同步的数据量："+totalNum);
			System.out.println("同步线程数："+syncThreadNum);
			System.out.println("每个线程可处理的数量"+ownerRecordNum);
			for(int i=0;i<syncThreadNum;i++){
				//postgresWR.selectArrage(tmpTBName, i*ownerRecordNum+1, i*ownerRecordNum+ownerRecordNum);
				Thread workThread=new Thread(
						new WorkerHandler(i*ownerRecordNum+1, i*ownerRecordNum+ownerRecordNum, tmpTBName));
				workThread.setName("SyncThread-"+i);
				workThread.start();
			}
			System.out.println("before");
			while(currentSynCount.get()<totalNum);System.out.println("in");
			System.out.println("finish");
			
		}
	}
	
	
	final class WorkerHandler implements Runnable{
		ResultSet coreRs;
		long start,end;	
		String targetTBName;
		public WorkerHandler(long start,long end,
				String targetTBName) {
			super();
			this.start=start;
			this.end=end;
			this.targetTBName = targetTBName;
		}
		@Override
		public void run() {
			try {
				
				launchSynData();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		void launchSynData() throws Exception{
			Class.forName(DataBase.WriteDataBase.driverClassName);
			
			Connection coreConnection=DriverManager.getConnection(DataBase.WriteDataBase.url,
					DataBase.WriteDataBase.username,
					DataBase.WriteDataBase.password);
			Statement coreStmt=coreConnection.createStatement();
			Class.forName(DataBase.ReadDataBase.driverClassName);
			Connection targetConnection=DriverManager.getConnection(DataBase.ReadDataBase.url,
					DataBase.ReadDataBase.username,
					DataBase.ReadDataBase.password);
			targetConnection.setAutoCommit(false);
			PreparedStatement pstate=targetConnection.prepareStatement(
					"insert into "+targetTBName+" values(?,?,?)"
					);
			
			StringBuilder sql=new StringBuilder()
			.append("select * from ")
			.append(targetTBName)
			.append(" where id between ")
			.append(start)
			.append(" and ")
			.append(end);
			
			coreRs=coreStmt.executeQuery(sql.toString());
			System.out.println("coreRs");
			int batchCounter=0;
			while(coreRs.next()){
				pstate.setLong(1, coreRs.getLong(1));
				pstate.setString(2, coreRs.getString(2));
				pstate.setString(3, coreRs.getString(3));
				pstate.addBatch();
				batchCounter++;
				currentSynCount.incrementAndGet();
				if(batchCounter%10000==0){
					pstate.executeBatch();
					pstate.clearBatch();
					targetConnection.commit();
				}
				pstate.executeBatch();
				pstate.clearBatch();
				targetConnection.commit();
				targetConnection.close();
				pstate.close();
				coreRs.close();
				
			}
			//System.out.println("finish");
		}
		
		
		
	}
}
