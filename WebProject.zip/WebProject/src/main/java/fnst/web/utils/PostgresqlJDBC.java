package fnst.web.utils;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//有问题
public class PostgresqlJDBC {
	private  Connection c=null;
	private  Statement state=null;
	private PreparedStatement pstate=null;
	private  ResultSet rs=null;
	private static PostgresqlJDBC postgresWR=null;
	private static PostgresqlJDBC postgresR=null;
	private DataBase database;
	
	private PostgresqlJDBC(DataBase database) {
		super();
		this.database=database;
	}
	
	public static PostgresqlJDBC createPostgresqlJava(DataBase database){
		if(database==DataBase.WriteDataBase){
			if(postgresWR==null){
				postgresWR=new PostgresqlJDBC(database);
				postgresWR.init();
			}
			return postgresWR;
		}
		
		if(database==DataBase.ReadDataBase){
			if(postgresR==null){
				postgresR=new PostgresqlJDBC(database);
				postgresR.init();
			}
			return postgresR;
		}
		return null;
		
	}


	
	public void dropTable(String tableName) {
		String sql="drop table "+tableName;
		try {
			state.executeUpdate(sql);
			System.out.println("Drop Table Successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}






	public void createTable(String sql) {
		/*String sql="create table human("
				+ "id int primary key not null,"
				+ "name text ,"
				+ "sex boolean"
				+ ")";*/
		if(argIsRight(sql)){
			try {
				state.execute(sql);
				System.out.println("Create Table Successfully!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}


	



	public PreparedStatement getPStatement(String sql){
		try {
			pstate=c.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pstate;
	}

	
	public void commit(){
		try {
			c.commit();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

	private void init(){
		try {
			Class.forName(database.driverClassName);
			c=DriverManager.getConnection(database.url,database.username,database.password);
			System.out.println("Open DB successfully!");
			state=c.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void close(){
		
		try {		if(rs!=null){
						rs.close();
					}
					if(pstate!=null){
						pstate.close();
					}
					state.close();			
					c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}
	
	
	public  boolean argIsRight(String sql){
		if(sql!=null&&!"".equals(sql)){
			return true;
		}else{
			return false;
		}
	}
	
	
	public ResultSet selectArrage(String tableName,long start,long end){
		if(!argIsRight(tableName)) throw new IllegalArgumentException();
		StringBuilder sql=new StringBuilder()
		.append("select * from ")
		.append(tableName)
		.append(" where id between ")
		.append(start)
		.append(" and ")
		.append(end);
		
		try {
			rs=state.executeQuery(sql.toString());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
		
	}
	
	//查找总数
	public ResultSet selectCount(String tableName){
		if(!argIsRight(tableName)) throw new IllegalArgumentException();
		String sql="select count(*) from "+tableName;
		try {
			rs=state.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	public void setAutoCommit(boolean isAuto){
		try {
			c.setAutoCommit(isAuto);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(String tableName){
		if(!argIsRight(tableName)) return;
		String sql="delete from "+tableName;
		try {
			System.out.println(state);
			state.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
