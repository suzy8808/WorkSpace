package fnst.web.utils;

import java.util.concurrent.atomic.AtomicLong;

public class UserApp {
	public static AtomicLong userNum=new AtomicLong(3000L);
}
