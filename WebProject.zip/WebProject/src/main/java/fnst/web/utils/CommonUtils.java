package fnst.web.utils;

import java.util.List;

import fnst.web.entity.Usr;

public class CommonUtils {
	public static long nullNum(List<Usr> objs){
		long count=0;
		for(Object obj:objs){
			if(obj==null){
				count++;
			}
		}
		return count;
	}
}
