package fnst.web.utils;

import java.io.File;



import java.io.IOException;
import java.nio.charset.Charset;

import com.google.common.collect.Lists;
import com.google.common.io.Files;

import redis.clients.jedis.Jedis;

public class Limiter {
	
	public static boolean acquire() throws IOException{
		
		 String luaScript = Files.toString(new File("D:/Lua/limit.lua"), Charset.defaultCharset());
		 Jedis jedis = new Jedis("localhost", 6379);
		 String key = "ip:" + System.currentTimeMillis()/ 1000; //此处将当前时间戳取秒数
		 String limit = "10"; //限流大小
		 return (Long)jedis.eval(luaScript,Lists.newArrayList(key), Lists.newArrayList(limit)) == 1;
	}
	
}
