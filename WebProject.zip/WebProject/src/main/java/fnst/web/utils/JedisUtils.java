package fnst.web.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import fnst.web.entity.Usr;
import fnst.web.service.IUsrService;
import redis.clients.jedis.Jedis;

public class JedisUtils {
	public static final Jedis jedis=new Jedis("localhost");
	public static final String USERS="users";
	
	public static List<Usr> findUserByRedis(List<Long> uIds){
		
		List<Usr> users=null;
		Jedis je=new Jedis("localhost");
		synchronized (je) {
		byte[] bytes=je.get(USERS.getBytes());
		
		if(bytes==null){
			users=new ArrayList<Usr>();
			for(int i=0;i<uIds.size();i++){
				users.add(null);
			}
		}else{
			users=(List<Usr>) unserizlize(bytes);
		}
		}
		je.close();
		return users;
		
	}
	
	
	
	
	
	//序列化 
    public static byte [] serialize(Object obj){
        ObjectOutputStream obi=null;
        ByteArrayOutputStream bai=null;
        try {
            bai=new ByteArrayOutputStream();
            obi=new ObjectOutputStream(bai);
            obi.writeObject(obj);
            byte[] byt=bai.toByteArray();
            return byt;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    //反序列化
    public static Object unserizlize(byte[] byt){
        ObjectInputStream oii=null;
        ByteArrayInputStream bis=null;
        bis=new ByteArrayInputStream(byt);
        try {
            oii=new ObjectInputStream(bis);
            Object obj=oii.readObject();
            return obj;
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    
        
        return null;
    }



	
}
