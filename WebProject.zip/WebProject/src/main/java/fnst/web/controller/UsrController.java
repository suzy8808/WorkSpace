package fnst.web.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLEncoder;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import redis.clients.jedis.Jedis;

import com.google.common.util.concurrent.RateLimiter;

import fnst.web.entity.Usr;
import fnst.web.service.IUsrService;
import fnst.web.service.IWordService;
import fnst.web.utils.CommonUtils;
import fnst.web.utils.CreateStaticHTMLPage;
import fnst.web.utils.JedisClient;
import fnst.web.utils.JedisUtils;
import fnst.web.utils.Limiter;
import fnst.web.utils.MD5Utils;
import fnst.web.utils.UserApp;
@RequestMapping("/usr")
@Controller
public class UsrController {

	@Autowired
	private IUsrService usrService;
	@Autowired
	private IWordService wordService;
	
	@Autowired
	private JedisClient jedisClient;
	
	RateLimiter rateLimiter=RateLimiter.create(10.0);
	
	@RequestMapping("/login")
	public String login(String name,String password,HttpServletRequest request){
		//System.out.println(name+"\t"+password);
		Usr user=usrService.login(name, password);
		if(user==null){
			return "index";
		}else{
			request.getSession().setAttribute("user", user);
			return "login_success";
		}
			
		
	}
	
	@RequestMapping("/write")
	public String write(String content,HttpServletRequest request) throws NoSuchAlgorithmException{
		HttpSession session=request.getSession();
		Usr user=(Usr) session.getAttribute("user");
		wordService.writeWord(user, content);
		return "login_success";
	}
	
	@RequestMapping("addUser")
	public void addUser(HttpServletRequest request,HttpServletResponse response) throws IOException{
		//System.out.println("等待时间："+rateLimiter.acquire());
		/*if(!rateLimiter.tryAcquire(1000,TimeUnit.MILLISECONDS)){
			System.out.println("添加失败");
			
		}
		Usr user=new Usr();
		user.setName("user"+UserApp.userNum.get());
		UserApp.userNum.incrementAndGet();
		user.setPassword("123");
		usrService.insertSelective(user);
		System.out.println("添加成功");*/
		if(!Limiter.acquire()){
			System.out.println("添加失败");
		}
		Usr user=new Usr();
		user.setName("user"+UserApp.userNum.get());
		UserApp.userNum.incrementAndGet();
		user.setPassword("123");
		usrService.insertSelective(user);
		System.out.println("添加成功");
		
	
	}
	
	
	@RequestMapping("/findUser")
	public void findUser(HttpServletResponse response){
		List<Long> uIds=new ArrayList<Long>();
		long start=System.currentTimeMillis();
		rateLimiter.acquire();
		for(long i=1300;i<1400;i++){
			uIds.add(i);
		}
		
		List<Usr> users=JedisUtils.findUserByRedis(uIds);
		//System.out.println("1:"+users.size());
		if(CommonUtils.nullNum(users)>uIds.size()/2){
			initJedis(users,uIds);
		}
		
		for(int i=0;i<users.size();i++){
			Usr u=users.get(i);
			if(u==null){
				System.out.println(users.size());
				u=usrService.selectByPrimaryKey(uIds.get(i));
				users.remove(i);
				users.add(i, u);
			}
			
		}
		long end=System.currentTimeMillis();
		System.out.println(end-start);
		
		try {
			response.sendRedirect("../login_success.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@RequestMapping("/secondkill")
	public void secondkill(){
		int num=10;
		Jedis jedis=new Jedis("localhost");
		
		if(jedis.llen("mer")<num){
			jedis.lpush("mer",""+(jedis.llen("mer")+1));
			System.out.println("秒杀成功");
		}else{
			System.out.println("秒杀失败");
		}
		
		jedis.close();
		
		
	}
	
	
	@RequestMapping("staticpage")
	public void staticpage(HttpServletRequest request,HttpServletResponse response) throws IOException, ServletException{
		/*String pageName="static.html";
		String pagePath=request.getServletContext().getRealPath("/")+pageName;
		System.out.println("==================="+pagePath);
		//System.out.println("==================="+request.getContextPath());
		//System.out.println("==================="+request.getRealPath(request.getServletPath()));
		File pageFile=new File(pagePath);
		if(pageFile.exists()){
			//System.out.println("1111");
			response.sendRedirect(request.getContextPath()+"/"+pageName);
			return;
		}
		request.setAttribute("name", "静态页面");
		new CreateStaticHTMLPage().createStaticHTMLPage(request, response, request.getServletContext(), pageName, pagePath, "/staticpage.jsp");*/
		response.sendRedirect(request.getContextPath()+"/staticpage.jsp");
		
	}
	
	
	@RequestMapping("useInterface")
	public void useInterface(HttpServletRequest request,HttpServletResponse response) throws IOException{
		//System.out.println("等待："+rateLimiter.acquire());
		System.out.println("调用API1");
		Jedis jedis=jedisClient.getResource();
		if(!jedis.exists("API Count")){
			jedis.zadd("API Count", 0,"API1");
		}
		
		jedis.zincrby("API Count", 1, "API1");
		
		
		System.out.println("当前API1一共被调用"+jedis.zscore("API Count", "API1"));
		jedisClient.returnResource(jedis);
		response.sendRedirect(request.getContextPath()+"/login_success.jsp");
	}
	
	
	
	
	@RequestMapping("/inputfile")
	public void inputfile(HttpServletRequest request,HttpServletResponse response){
		InputStream is=null;
		FileOutputStream  os=null;
		String fileName=null;
		File file=null;
		String fileType=null;
		FileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload upload=new ServletFileUpload(factory);
		try {
			List items=upload.parseRequest(request);
			Iterator iter=items.iterator();
			while(iter.hasNext()){
				FileItem item=(FileItem) iter.next();
				if(!item.isFormField()){
					file=new File("D:/"+MD5Utils.EncoderByMd5(""+new Date().getTime()));
					if(!file.exists())file.createNewFile();
					os=new FileOutputStream(file);
					is=item.getInputStream();
					byte[] b=new byte[512];
					while(is.read(b)>0){
						os.write(b);
					}
					is.close();
					os.close();
					String name=item.getName();
					System.out.println("file:"+name);
					fileType=name.substring(name.lastIndexOf('.'), name.length());
					System.out.println("fileType:"+fileType);
				}else{
					if("filename".equals(item.getFieldName())){
						
						fileName=new String(item.getString().getBytes("iso-8859-1"),"utf-8");
						System.out.println("fileName:"+fileName);
					}
				}
				
			}
			
			if(file!=null&&fileName!=null&&fileType!=null){
				file.renameTo(new File("D:/"+fileName+fileType));
			}
			
		} catch (FileUploadException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			response.sendRedirect("../login_success.jsp");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping("/download")
	public void download(String path,boolean isOnline,HttpServletRequest request,HttpServletResponse response){
		  try {
			  	System.out.println(path);
	            // path是指欲下载的文件的路径。
	            File file = new File(path);
	            
	            // 取得文件名。
	            String filename = file.getName();
	          
	            System.out.println(file.exists());
	            // 以流的形式下载文件。
	            FileInputStream fis = new FileInputStream(file);
	            byte[] buffer = new byte[fis.available()];
	            fis.read(buffer);
	            fis.close();
	            // 清空response
	            response.reset();
	            if(isOnline){
	            	 URL u = new URL("file:///" + path);
	                 response.setContentType(u.openConnection().getContentType());
	                 response.setHeader("Content-Disposition", "inline; filename=" + URLEncoder.encode(filename,"UTF-8"));
	            }else{
		            // 设置response的Header
		            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(filename,"UTF-8"));
		            response.addHeader("Content-Length", "" + file.length());
	            }
	            OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
	            response.setContentType("application/octet-stream");
	            toClient.write(buffer);
	            toClient.flush();
	            toClient.close();
	        } catch (IOException ex) {
	            ex.printStackTrace();
	        }
	        

	}
	
	
	 public  void initJedis(List<Usr> users, List<Long> uIds) {
		for(int i=0;i<uIds.size();i++){
			Usr u=users.get(i);
			if(u==null){
				//System.out.println(usrService);
				//System.out.println(uIds.size()+"\t"+users.size());
				u=usrService.selectByPrimaryKey(uIds.get(i));
				users.remove(i);
				users.add(i, u);
				//System.out.println(u);
			}
			
		}
		//System.out.println("2:"+users.size());
		JedisUtils.jedis.del(JedisUtils.USERS.getBytes());
		JedisUtils.jedis.set(JedisUtils.USERS.getBytes(), JedisUtils.serialize(users));
		JedisUtils.jedis.expire(JedisUtils.USERS.getBytes(), 60);
		
	}
}
