package fnst.web.test;

import java.security.NoSuchAlgorithmException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import redis.clients.jedis.Jedis;
import fnst.web.entity.Usr;
import fnst.web.service.IWordService;
import fnst.web.service.impl.WordService;
import fnst.web.utils.JedisClient;
import fnst.web.utils.MD5Utils;


@RunWith(SpringJUnit4ClassRunner.class)//4.1.2以上版本
@ContextConfiguration("classpath*:applicationContext.xml")
public class WordTest {
	@Autowired
	private IWordService wordService;
	@Autowired
	private JedisClient jedisClient;
	
	@Before
	public void init(){}
	
	@Test
	public void testWriteWord() throws NoSuchAlgorithmException{
		Jedis jedis=jedisClient.getResource();
		System.out.println(jedis.zscore("API Count", "API1")+jedis.toString());
		jedisClient.returnResource(jedis);
		System.out.println(jedis.zscore("API Count", "API1")+jedis.toString());
		
	}
}
