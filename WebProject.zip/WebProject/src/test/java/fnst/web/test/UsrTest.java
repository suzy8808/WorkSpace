package fnst.web.test;

import java.security.NoSuchAlgorithmException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import fnst.web.entity.Usr;
import fnst.web.service.IUsrService;
import fnst.web.utils.MD5Utils;

@RunWith(SpringJUnit4ClassRunner.class)//4.1.2以上版本
@ContextConfiguration("classpath*:applicationContext.xml")
public class UsrTest {
	@Autowired
	private IUsrService usrService;
	
	
	
	@Before
	public void init(){}
	
	@Test
	public void testLogin() throws NoSuchAlgorithmException{
		Usr usr=new Usr();
		usr.setName("张无忌");
		usr.setPassword("123");
		usrService.insertSelective(usr);
		Usr usr2=new Usr();
		usr2.setName("赵敏");
		usr2.setPassword("123");
		usrService.insertSelective(usr2);
		Usr usr3=new Usr();
		usr3.setName("周芷若");
		usr3.setPassword("123");
		usrService.insertSelective(usr3);
		Usr usr4=new Usr();
		usr4.setName("郭靖");
		usr4.setPassword("123");
		usrService.insertSelective(usr4);
		Usr usr5=new Usr();
		usr5.setName("黄蓉");
		usr5.setPassword("123");
		usrService.insertSelective(usr5);
		Usr usr6=new Usr();
		usr6.setName("杨过");
		usr6.setPassword("123");
		usrService.insertSelective(usr6);
		Usr usr7=new Usr();
		usr7.setName("小龙女");
		usr7.setPassword("123");
		usrService.insertSelective(usr7);
		Usr usr8=new Usr();
		usr8.setName("花无缺");
		usr8.setPassword("123");
		usrService.insertSelective(usr8);
		Usr usr9=new Usr();
		usr9.setName("小鱼儿");
		usr9.setPassword("123");
		usrService.insertSelective(usr9);
		Usr usr10=new Usr();
		usr10.setName("达摩");
		usr10.setPassword("123");
		usrService.insertSelective(usr10);
		
		
		System.out.println(usrService.selectByPrimaryKey(1L));
	}
}
