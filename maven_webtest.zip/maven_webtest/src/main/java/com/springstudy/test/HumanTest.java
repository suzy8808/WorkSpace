package com.springstudy.test;


import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.google.common.util.concurrent.RateLimiter;
import com.springstudy.dao.HumanMapper;



public class HumanTest {

	HumanMapper humanDao=null;
	
	@Before
	public void init(){
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext(
						
								"classpath*:applicationContext.xml"
							
						);	
		//System.out.println(applicationContext.containsBean("humanDao"));
		humanDao=(HumanMapper) applicationContext.getBean("humanDao");
		//System.out.println("111111111111111111");
	}
	
	@Test
	public void testSelectByPrimaryKey() throws InterruptedException{
		Thread t1=new Thread(new SelectRunning());
		t1.setName("t1");
		t1.start();
		
		while(t1.isAlive());
		
		
		
	}
	
	class SelectRunning implements Runnable{

		@Override
		public void run() {
			RateLimiter rateLimiter=RateLimiter.create(10.0);
			for(int i=0;i<10000;i++){
				rateLimiter.acquire();
				System.out.println(Thread.currentThread().getName()+":\t"+humanDao.selectByPrimaryKey(i%7+1));
			}
			
		}
		
	}
	
}
