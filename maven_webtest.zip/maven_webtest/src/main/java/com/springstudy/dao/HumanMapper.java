package com.springstudy.dao;

import org.springframework.stereotype.Repository;

import com.springstudy.entity.Human;

@Repository(value="humanDao")
public interface HumanMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(Human record);

    int insertSelective(Human record);

    Human selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Human record);

    int updateByPrimaryKey(Human record);
}