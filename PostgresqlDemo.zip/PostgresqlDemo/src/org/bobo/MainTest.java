package org.bobo;

public class MainTest {

	public static void main(String[] args) {
		PostgresqlJava postgres=PostgresqlJava.createPostgresqlJava();
		//删表
		//postgres.dropTable("human");
		//建表
		/*String sql="create table human("
				+ "id int primary key not null,"
				+ "name text ,"
				+ "sex boolean"
				+ ")";
		postgres.createTable(sql);*/
		
		//插入
		/*String sql1="insert into human(id,name,sex) values(1,'张无忌',true)";
		String sql2="insert into human(id,name,sex) values(2,'赵敏',false)";
		String sql3="insert into human(id,name,sex) values(3,'萧峰',true)";
		String sql4="insert into human(id,name,sex) values(4,'张三丰',true)";
		String sql5="insert into human(id,name,sex) values(5,'杨过',true)";
		String sql6="insert into human(id,name,sex) values(6,'小龙女',false)";
		String sql7="insert into human(id,name,sex) values(7,'灭绝师太',false)";
		postgres.insert(sql1);
		postgres.insert(sql2);
		postgres.insert(sql3);
		postgres.insert(sql4);
		postgres.insert(sql5);
		postgres.insert(sql6);
		postgres.insert(sql7);*/
		//查所有
		//postgres.selectAll("human");
		
		
		postgres.close();
	}

}
