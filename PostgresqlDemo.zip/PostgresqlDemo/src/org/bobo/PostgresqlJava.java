package org.bobo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PostgresqlJava {
	private  Connection c=null;
	private  Statement state=null;
	private  ResultSet rs=null;
	private static PostgresqlJava postgres=null;
	
	
	private PostgresqlJava() {
		super();
	}
	
	public static PostgresqlJava createPostgresqlJava(){
		if(postgres==null){
			postgres=new PostgresqlJava();
			postgres.init();
		}
		
		return postgres;
	}


	
	public void dropTable(String tableName) {
		String sql="drop table "+tableName;
		try {
			state.executeUpdate(sql);
			System.out.println("Drop Table Successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
	}






	public void createTable(String sql) {
		/*String sql="create table human("
				+ "id int primary key not null,"
				+ "name text ,"
				+ "sex boolean"
				+ ")";*/
		if(argIsRight(sql)){
			try {
				state.execute(sql);
				System.out.println("Create Table Successfully!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}


	public  void insert(String sql){
		
		if(argIsRight(sql)){
			try {
				state.executeUpdate(sql);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			System.out.println("参数有问题");
			return;
		}
		
	}



	private void init(){
		try {
			Class.forName("org.postgresql.Driver");
			c=DriverManager.getConnection("jdbc:postgresql://localhost:5432/xyb_db","postgres","fnst1234");
			System.out.println("Open DB successfully!");
			state=c.createStatement();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void close(){
		
		try {		if(rs!=null){
						rs.close();
					}
					state.close();			
					c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		
	}
	
	public  void commit(){
		try {
			c.commit();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public  boolean argIsRight(String sql){
		if(sql!=null&&!"".equals(sql)){
			return true;
		}else{
			return false;
		}
	}
	
	//可移植性差
	public void selectAll(String tableName){
		if(argIsRight(tableName)) return;
		String sql="select * from "+tableName;
		try {
			rs=state.executeQuery(sql);
			while(rs.next()){
				int id=rs.getInt("id");
				String name=rs.getString("name");
				boolean sex=rs.getBoolean("sex");
				System.out.println("id="+id+"\t name="+name+"\t sex="+(sex?"男":"女"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(String tableName){
		if(argIsRight(tableName)) return;
		String sql="delete from "+tableName;
		try {
			state.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
