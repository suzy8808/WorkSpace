package ratelimiter;

import com.google.common.util.concurrent.RateLimiter;


public class RateLimiterTest {
	  public static void main(String[] args) {
	    	testNoRateLimiter();
	    	testWithRateLimiter();
	    
	    }
	 
	    private static void testWithRateLimiter() {
	    	Long start = System.currentTimeMillis();
	    	RateLimiter rateLimiter=RateLimiter.create(10.0);
	        for (int i = 0; i < 20; i++) {
	        	rateLimiter.acquire();
	            System.out.println("call execute.." + i);
	            
	        }
	        Long end = System.currentTimeMillis();
	        
	        System.out.println(end - start);
		
	    }

		public static void testNoRateLimiter() {
	    	Long start = System.currentTimeMillis();
	        for (int i = 0; i < 10; i++) {
	            System.out.println("call execute.." + i);
	            
	        }
	        Long end = System.currentTimeMillis();
	        
	        System.out.println(end - start);
	        
	    }
	    
	  
}        
	    

