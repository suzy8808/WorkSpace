package fnst.swagger.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;

@Api(value="APIController")
@Controller
public class APIController{
	@ApiOperation(value="加法",httpMethod="GET",notes="add",response=String.class)
	@RequestMapping("/add")
	public String add(@ApiParam(value="a",name="a",required=true)@RequestParam(value="a") int a,
			@ApiParam(value="b",name="b",required=true)@RequestParam(value="b") int b){
		System.out.println(a+b);
		return "index";
	}
}
