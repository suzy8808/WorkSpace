package org.bobo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import redis.clients.jedis.Jedis;

public class RedisJava {
	public static void main(String[] args) throws Exception{
		Jedis jedis=new Jedis("localhost");
		/*System.out.println("Redis connects successfully");
		System.out.println("starting");
		jedis.set("hello", "word");
		System.out.println(jedis.get("hello"));
		jedis.expire("hello", 10);
		while(jedis.get("hello")!=null){
			System.out.println("hello has "+jedis.ttl("hello")+"s");
			Thread.sleep(1000);
		}*/
		/*Person p=new Person("张三","123");
		Person p2=new Person("张三","123");
		List<Person> ps=new ArrayList<Person>();
		ps.add(p);
		ps.add(p2);
		jedis.set("persons".getBytes(), serialize(ps));
		System.out.println((List<Person>)unserizlize(jedis.get("persons".getBytes())));
		
		jedis.lpush("name", new String[]{"1","2","3"});
		System.out.println(jedis.lrange("name",1,jedis.llen("name")));
		System.out.println(jedis.llen("key"));*/
		
		
		System.out.println(jedis.zscore("API Count", "API1"));
		jedis.close();
		System.out.println(jedis.zscore("API Count", "API2"));
		
	}
	//序列化 
    public static byte [] serialize(Object obj){
        ObjectOutputStream obi=null;
        ByteArrayOutputStream bai=null;
        try {
            bai=new ByteArrayOutputStream();
            obi=new ObjectOutputStream(bai);
            obi.writeObject(obj);
            byte[] byt=bai.toByteArray();
            return byt;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    //反序列化
    public static Object unserizlize(byte[] byt){
        ObjectInputStream oii=null;
        ByteArrayInputStream bis=null;
        bis=new ByteArrayInputStream(byt);
        try {
            oii=new ObjectInputStream(bis);
            Object obj=oii.readObject();
            return obj;
        } catch (Exception e) {
            
            e.printStackTrace();
        }
    
        
        return null;
    }

	
	
}

class Person implements Serializable{
	String name;
	String password;
	
	public Person() {
		super();
	}
	public Person(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", password=" + password + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
}
